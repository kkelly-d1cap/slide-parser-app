import os
import uuid
import tempfile
from flask import Blueprint, request, jsonify, current_app, send_file
from werkzeug.utils import secure_filename
from pdf2image import convert_from_path
import boto3
from botocore.exceptions import ClientError
from PIL import Image
import io
import base64

slides_bp = Blueprint('slides', __name__)

# Configuration
ALLOWED_EXTENSIONS = {'pdf'}
MAX_FILE_SIZE = 50 * 1024 * 1024  # 50MB
CATEGORIES = ['Summary', 'Track Record', 'Details', 'Team']

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def get_s3_client():
    """Initialize S3 client with environment variables"""
    try:
        return boto3.client(
            's3',
            aws_access_key_id=os.environ.get('AWS_ACCESS_KEY_ID'),
            aws_secret_access_key=os.environ.get('AWS_SECRET_ACCESS_KEY'),
            region_name=os.environ.get('AWS_REGION', 'us-east-1')
        )
    except Exception as e:
        current_app.logger.error(f"Failed to initialize S3 client: {str(e)}")
        return None

def sanitize_filename(text):
    """Sanitize text for use in filenames"""
    import re
    # Remove special characters and replace spaces with underscores
    sanitized = re.sub(r'[^\w\s-]', '', text)
    sanitized = re.sub(r'[-\s]+', '_', sanitized)
    return sanitized.strip('_')

@slides_bp.route('/upload', methods=['POST'])
def upload_pdf():
    """Upload PDF and extract slides as images"""
    try:
        # Check if file is present
        if 'file' not in request.files:
            return jsonify({'error': 'No file provided'}), 400
        
        file = request.files['file']
        fund_id = request.form.get('fund_id', '').strip()
        fund_name = request.form.get('fund_name', '').strip()
        
        # Validate fund information
        if not fund_id or not fund_name:
            return jsonify({'error': 'Fund ID and Fund Name are required'}), 400
        
        # Sanitize fund information for filenames
        safe_fund_id = sanitize_filename(fund_id)
        safe_fund_name = sanitize_filename(fund_name)
        
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        # Validate file
        if not allowed_file(file.filename):
            return jsonify({'error': 'Only PDF files are allowed'}), 400
        
        # Check file size
        file.seek(0, os.SEEK_END)
        file_size = file.tell()
        file.seek(0)
        
        if file_size > MAX_FILE_SIZE:
            return jsonify({'error': 'File size exceeds 50MB limit'}), 400
        
        # Generate unique session ID
        session_id = str(uuid.uuid4())
        
        # Save uploaded file temporarily
        filename = secure_filename(file.filename)
        temp_dir = tempfile.mkdtemp()
        temp_pdf_path = os.path.join(temp_dir, filename)
        file.save(temp_pdf_path)
        
        # Convert PDF to images
        try:
            images = convert_from_path(temp_pdf_path, dpi=150)
        except Exception as e:
            return jsonify({'error': f'Failed to process PDF: {str(e)}'}), 500
        
        # Create thumbnails and prepare response
        slides_data = []
        temp_images_dir = os.path.join(temp_dir, 'slides')
        os.makedirs(temp_images_dir, exist_ok=True)
        
        for i, image in enumerate(images):
            # Create thumbnail
            thumbnail = image.copy()
            thumbnail.thumbnail((300, 400), Image.Resampling.LANCZOS)
            
            # Save thumbnail temporarily
            thumbnail_path = os.path.join(temp_images_dir, f'slide_{i+1}_thumb.png')
            thumbnail.save(thumbnail_path, 'PNG')
            
            # Convert thumbnail to base64 for preview
            img_buffer = io.BytesIO()
            thumbnail.save(img_buffer, format='PNG')
            img_buffer.seek(0)
            thumbnail_b64 = base64.b64encode(img_buffer.getvalue()).decode()
            
            # Save full-size image temporarily with fund prefix
            slide_filename = f'{safe_fund_id}_{safe_fund_name}_slide_{i+1}.png'
            full_image_path = os.path.join(temp_images_dir, slide_filename)
            image.save(full_image_path, 'PNG')
            
            slides_data.append({
                'page': i + 1,
                'thumbnail_b64': f'data:image/png;base64,{thumbnail_b64}',
                'temp_path': full_image_path,
                'filename': slide_filename,
                'selected': False,
                'category': None
            })
        
        # Store session data (in production, use Redis or database)
        session_data = {
            'session_id': session_id,
            'filename': filename,
            'temp_dir': temp_dir,
            'slides': slides_data,
            'total_slides': len(slides_data),
            'fund_id': fund_id,
            'fund_name': fund_name,
            'safe_fund_id': safe_fund_id,
            'safe_fund_name': safe_fund_name
        }
        
        # Clean up original PDF
        os.remove(temp_pdf_path)
        
        return jsonify({
            'session_id': session_id,
            'filename': filename,
            'total_slides': len(slides_data),
            'slides': slides_data,
            'categories': CATEGORIES,
            'fund_info': {
                'fund_id': fund_id,
                'fund_name': fund_name,
                'file_prefix': f'{safe_fund_id}_{safe_fund_name}'
            }
        })
        
    except Exception as e:
        current_app.logger.error(f"Upload error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@slides_bp.route('/process', methods=['POST'])
def process_slides():
    """Process selected slides, upload to S3, and generate HTML"""
    try:
        data = request.get_json()
        session_id = data.get('session_id')
        selected_slides = data.get('slides', [])
        s3_bucket = data.get('s3_bucket')
        
        if not session_id or not selected_slides or not s3_bucket:
            return jsonify({'error': 'Missing required parameters'}), 400
        
        # Initialize S3 client
        s3_client = get_s3_client()
        if not s3_client:
            return jsonify({'error': 'S3 configuration error'}), 500
        
        # Process each selected slide
        processed_slides = {}
        s3_urls = {}
        
        for slide in selected_slides:
            if not slide.get('selected') or not slide.get('category'):
                continue
                
            page = slide['page']
            category = slide['category']
            temp_path = slide['temp_path']
            
            if not os.path.exists(temp_path):
                continue
            
            # Generate S3 key
            s3_key = f"presentations/{session_id}/slides/{category.lower()}/slide_{page}.png"
            
            try:
                # Upload to S3
                with open(temp_path, 'rb') as f:
                    s3_client.upload_fileobj(
                        f, 
                        s3_bucket, 
                        s3_key,
                        ExtraArgs={'ContentType': 'image/png', 'ACL': 'public-read'}
                    )
                
                # Generate public URL
                s3_url = f"https://{s3_bucket}.s3.amazonaws.com/{s3_key}"
                
                # Group by category
                if category not in processed_slides:
                    processed_slides[category] = []
                    s3_urls[category] = []
                
                processed_slides[category].append({
                    'page': page,
                    's3_url': s3_url,
                    's3_key': s3_key
                })
                s3_urls[category].append(s3_url)
                
            except ClientError as e:
                current_app.logger.error(f"S3 upload error: {str(e)}")
                return jsonify({'error': f'Failed to upload slide {page} to S3'}), 500
        
        # Import HTML generation utilities
        from src.utils.html_generator import (
            generate_basic_html, 
            generate_modal_html, 
            generate_grid_html,
            generate_complete_html_template,
            generate_css_styles,
            generate_javascript
        )
        
        # Generate HTML snippets in different formats
        html_snippets = {
            'basic': {},
            'modal': {},
            'grid': {}
        }
        
        for category, slides in processed_slides.items():
            html_snippets['basic'][category] = generate_basic_html(category, slides)
            html_snippets['modal'][category] = generate_modal_html(category, slides)
            html_snippets['grid'][category] = generate_grid_html(category, slides)
        
        # Generate complete HTML templates
        complete_templates = {
            'basic': generate_complete_html_template(processed_slides, 'basic'),
            'modal': generate_complete_html_template(processed_slides, 'modal'),
            'grid': generate_complete_html_template(processed_slides, 'grid')
        }
        
        # Generate CSS and JavaScript separately
        css_styles = generate_css_styles()
        javascript_code = generate_javascript()
        
        return jsonify({
            'success': True,
            'processed_slides': processed_slides,
            'html_snippets': html_snippets,
            'complete_templates': complete_templates,
            'css_styles': css_styles,
            'javascript_code': javascript_code,
            's3_urls': s3_urls,
            'template_types': ['basic', 'modal', 'grid']
        })
        
    except Exception as e:
        current_app.logger.error(f"Process error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@slides_bp.route('/preview/<session_id>/<int:page>', methods=['GET'])
def get_slide_preview(session_id, page):
    """Get slide preview image"""
    try:
        # In production, retrieve from session storage
        # For now, return placeholder
        return jsonify({'error': 'Preview not implemented yet'}), 501
        
    except Exception as e:
        current_app.logger.error(f"Preview error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@slides_bp.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'service': 'slide-parser',
        'categories': CATEGORIES
    })

