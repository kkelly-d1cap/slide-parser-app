"""
HTML Generation utilities for slide parser application
"""

def generate_basic_html(category, slides):
    """Generate basic HTML snippet for a category"""
    html_parts = []
    html_parts.append(f'<div class="category-section" data-category="{category.lower()}">')
    html_parts.append(f'  <h2>{category}</h2>')
    html_parts.append('  <div class="slides-container">')
    
    for slide in slides:
        html_parts.append(f'    <div class="slide" data-page="{slide["page"]}">')
        html_parts.append(f'      <img src="{slide["s3_url"]}" alt="{category} - Slide {slide["page"]}" class="slide-image" />')
        html_parts.append('    </div>')
    
    html_parts.append('  </div>')
    html_parts.append('</div>')
    
    return '\n'.join(html_parts)

def generate_modal_html(category, slides):
    """Generate HTML with modal functionality"""
    modal_id = f"modal-{category.lower().replace(' ', '-')}"
    
    html_parts = []
    
    # Trigger button
    html_parts.append(f'<button class="category-trigger" data-modal="{modal_id}">')
    html_parts.append(f'  View {category} ({len(slides)} slides)')
    html_parts.append('</button>')
    
    # Modal structure
    html_parts.append(f'<div id="{modal_id}" class="slide-modal" style="display: none;">')
    html_parts.append('  <div class="modal-content">')
    html_parts.append('    <div class="modal-header">')
    html_parts.append(f'      <h2>{category}</h2>')
    html_parts.append('      <span class="close">&times;</span>')
    html_parts.append('    </div>')
    html_parts.append('    <div class="modal-body">')
    html_parts.append('      <div class="slides-carousel">')
    
    for i, slide in enumerate(slides):
        active_class = "active" if i == 0 else ""
        html_parts.append(f'        <div class="slide-item {active_class}" data-slide="{i}">')
        html_parts.append(f'          <img src="{slide["s3_url"]}" alt="{category} - Slide {slide["page"]}" />')
        html_parts.append(f'          <div class="slide-info">Slide {slide["page"]}</div>')
        html_parts.append('        </div>')
    
    html_parts.append('      </div>')
    
    # Navigation controls
    if len(slides) > 1:
        html_parts.append('      <div class="carousel-controls">')
        html_parts.append('        <button class="prev-slide">‹ Previous</button>')
        html_parts.append('        <button class="next-slide">Next ›</button>')
        html_parts.append('      </div>')
    
    html_parts.append('    </div>')
    html_parts.append('  </div>')
    html_parts.append('</div>')
    
    return '\n'.join(html_parts)

def generate_grid_html(category, slides):
    """Generate HTML with grid layout"""
    html_parts = []
    html_parts.append(f'<div class="category-grid" data-category="{category.lower()}">')
    html_parts.append(f'  <h2 class="category-title">{category}</h2>')
    html_parts.append('  <div class="slides-grid">')
    
    for slide in slides:
        html_parts.append(f'    <div class="slide-card" data-page="{slide["page"]}">')
        html_parts.append(f'      <img src="{slide["s3_url"]}" alt="{category} - Slide {slide["page"]}" class="slide-thumbnail" />')
        html_parts.append(f'      <div class="slide-caption">Slide {slide["page"]}</div>')
        html_parts.append('    </div>')
    
    html_parts.append('  </div>')
    html_parts.append('</div>')
    
    return '\n'.join(html_parts)

def generate_css_styles():
    """Generate CSS styles for the HTML components"""
    css = """
/* Basic Slide Styles */
.category-section {
    margin: 20px 0;
    padding: 20px;
    border: 1px solid #ddd;
    border-radius: 8px;
    background: #f9f9f9;
}

.category-section h2 {
    margin: 0 0 15px 0;
    color: #333;
    font-size: 24px;
}

.slides-container {
    display: flex;
    flex-wrap: wrap;
    gap: 15px;
}

.slide {
    flex: 0 0 auto;
    max-width: 300px;
}

.slide-image {
    width: 100%;
    height: auto;
    border-radius: 4px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    transition: transform 0.2s ease;
}

.slide-image:hover {
    transform: scale(1.05);
}

/* Modal Styles */
.category-trigger {
    background: #007bff;
    color: white;
    border: none;
    padding: 12px 24px;
    border-radius: 6px;
    cursor: pointer;
    font-size: 16px;
    margin: 10px;
    transition: background 0.2s ease;
}

.category-trigger:hover {
    background: #0056b3;
}

.slide-modal {
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0,0,0,0.8);
}

.modal-content {
    background-color: #fefefe;
    margin: 5% auto;
    padding: 0;
    border-radius: 8px;
    width: 90%;
    max-width: 800px;
    max-height: 80vh;
    overflow: hidden;
}

.modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20px;
    border-bottom: 1px solid #ddd;
    background: #f8f9fa;
}

.modal-header h2 {
    margin: 0;
    color: #333;
}

.close {
    font-size: 28px;
    font-weight: bold;
    cursor: pointer;
    color: #aaa;
}

.close:hover {
    color: #000;
}

.modal-body {
    padding: 20px;
    text-align: center;
}

.slides-carousel {
    position: relative;
    max-height: 500px;
    overflow: hidden;
}

.slide-item {
    display: none;
}

.slide-item.active {
    display: block;
}

.slide-item img {
    max-width: 100%;
    max-height: 500px;
    object-fit: contain;
}

.slide-info {
    margin-top: 10px;
    font-size: 14px;
    color: #666;
}

.carousel-controls {
    margin-top: 20px;
}

.prev-slide, .next-slide {
    background: #6c757d;
    color: white;
    border: none;
    padding: 10px 20px;
    margin: 0 10px;
    border-radius: 4px;
    cursor: pointer;
}

.prev-slide:hover, .next-slide:hover {
    background: #545b62;
}

/* Grid Styles */
.category-grid {
    margin: 30px 0;
    padding: 20px;
    background: white;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.category-title {
    margin: 0 0 20px 0;
    color: #333;
    font-size: 28px;
    text-align: center;
    border-bottom: 2px solid #007bff;
    padding-bottom: 10px;
}

.slides-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
}

.slide-card {
    background: white;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.slide-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 20px rgba(0,0,0,0.15);
}

.slide-thumbnail {
    width: 100%;
    height: 200px;
    object-fit: cover;
}

.slide-caption {
    padding: 15px;
    text-align: center;
    font-weight: 500;
    color: #555;
    background: #f8f9fa;
}

/* Responsive Design */
@media (max-width: 768px) {
    .modal-content {
        width: 95%;
        margin: 10% auto;
    }
    
    .slides-container {
        justify-content: center;
    }
    
    .slides-grid {
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 15px;
    }
}
"""
    return css

def generate_javascript():
    """Generate JavaScript for modal functionality"""
    js = """
// Modal functionality
document.addEventListener('DOMContentLoaded', function() {
    // Modal triggers
    const triggers = document.querySelectorAll('.category-trigger');
    const modals = document.querySelectorAll('.slide-modal');
    const closeButtons = document.querySelectorAll('.close');
    
    // Open modal
    triggers.forEach(trigger => {
        trigger.addEventListener('click', function() {
            const modalId = this.getAttribute('data-modal');
            const modal = document.getElementById(modalId);
            if (modal) {
                modal.style.display = 'block';
            }
        });
    });
    
    // Close modal
    closeButtons.forEach(closeBtn => {
        closeBtn.addEventListener('click', function() {
            this.closest('.slide-modal').style.display = 'none';
        });
    });
    
    // Close modal when clicking outside
    modals.forEach(modal => {
        modal.addEventListener('click', function(e) {
            if (e.target === this) {
                this.style.display = 'none';
            }
        });
    });
    
    // Carousel functionality
    const prevButtons = document.querySelectorAll('.prev-slide');
    const nextButtons = document.querySelectorAll('.next-slide');
    
    prevButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const carousel = this.closest('.modal-body').querySelector('.slides-carousel');
            const slides = carousel.querySelectorAll('.slide-item');
            const activeSlide = carousel.querySelector('.slide-item.active');
            const currentIndex = Array.from(slides).indexOf(activeSlide);
            const prevIndex = currentIndex > 0 ? currentIndex - 1 : slides.length - 1;
            
            activeSlide.classList.remove('active');
            slides[prevIndex].classList.add('active');
        });
    });
    
    nextButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const carousel = this.closest('.modal-body').querySelector('.slides-carousel');
            const slides = carousel.querySelectorAll('.slide-item');
            const activeSlide = carousel.querySelector('.slide-item.active');
            const currentIndex = Array.from(slides).indexOf(activeSlide);
            const nextIndex = currentIndex < slides.length - 1 ? currentIndex + 1 : 0;
            
            activeSlide.classList.remove('active');
            slides[nextIndex].classList.add('active');
        });
    });
    
    // Keyboard navigation
    document.addEventListener('keydown', function(e) {
        const openModal = document.querySelector('.slide-modal[style*="block"]');
        if (openModal) {
            if (e.key === 'Escape') {
                openModal.style.display = 'none';
            } else if (e.key === 'ArrowLeft') {
                openModal.querySelector('.prev-slide')?.click();
            } else if (e.key === 'ArrowRight') {
                openModal.querySelector('.next-slide')?.click();
            }
        }
    });
});
"""
    return js

def generate_complete_html_template(processed_slides, template_type="basic"):
    """Generate complete HTML document with all categories"""
    categories = ['Summary', 'Track Record', 'Details', 'Team']
    
    html_parts = []
    html_parts.append('<!DOCTYPE html>')
    html_parts.append('<html lang="en">')
    html_parts.append('<head>')
    html_parts.append('    <meta charset="UTF-8">')
    html_parts.append('    <meta name="viewport" content="width=device-width, initial-scale=1.0">')
    html_parts.append('    <title>Presentation Slides</title>')
    html_parts.append('    <style>')
    html_parts.append(generate_css_styles())
    html_parts.append('    </style>')
    html_parts.append('</head>')
    html_parts.append('<body>')
    html_parts.append('    <div class="presentation-container">')
    html_parts.append('        <h1>Presentation Overview</h1>')
    
    # Generate content for each category
    for category in categories:
        if category in processed_slides and processed_slides[category]:
            if template_type == "modal":
                html_parts.append('        ' + generate_modal_html(category, processed_slides[category]))
            elif template_type == "grid":
                html_parts.append('        ' + generate_grid_html(category, processed_slides[category]))
            else:
                html_parts.append('        ' + generate_basic_html(category, processed_slides[category]))
    
    html_parts.append('    </div>')
    html_parts.append('    <script>')
    html_parts.append(generate_javascript())
    html_parts.append('    </script>')
    html_parts.append('</body>')
    html_parts.append('</html>')
    
    return '\n'.join(html_parts)

