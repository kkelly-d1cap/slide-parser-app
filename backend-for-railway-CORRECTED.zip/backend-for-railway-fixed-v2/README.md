# Slide Parser Backend - Railway Ready

## 🚀 Production-Ready Flask Backend

This is the updated backend package with Gunicorn production server configuration for Railway deployment.

## 📁 Files Included

- `main.py` - Flask application with Gunicorn compatibility
- `requirements.txt` - Dependencies including Gunicorn
- `Procfile` - Railway deployment configuration
- `src/` - Application source code structure

## 🔧 Key Updates

### ✅ Production Server
- Added Gunicorn WSGI server
- Configured for Railway deployment
- No more "development server" warnings

### ✅ Environment Variables Required
```
PORT=5000
FLASK_ENV=production
AWS_ACCESS_KEY_ID=your-key
AWS_SECRET_ACCESS_KEY=your-secret
AWS_REGION=us-east-1
S3_BUCKET_NAME=your-bucket
```

### ✅ Endpoints Available
- `/health` - Health check
- `/api/test` - API test endpoint
- `/api/upload` - PDF upload and processing
- `/api/generate-html` - HTML code generation

## 🚂 Railway Deployment

1. Upload this entire folder to Railway
2. Set environment variables
3. Railway will automatically use the Procfile
4. Gunicorn will start the production server

## ✅ Expected Results

After deployment, you should see in Railway logs:
```
Starting gunicorn 21.2.0
Listening at: http://0.0.0.0:5000
Using worker: sync
Booting worker with pid: 123
```

## 🎯 Testing

Visit these URLs after deployment:
- `https://your-app.railway.app/health` → `{"status":"healthy","server":"gunicorn"}`
- `https://your-app.railway.app/api/test` → API status information

No more Bad Gateway errors!

